function Footer() {
    return (

        <div>
           <div className="bg-gray-800 text-center text-white p-3">Footer</div>
        </div>

    )
}

export default Footer;