function Buttons(props) {
    let variantStyles = "text-white font-bold py-2 px-4 rounded"
    if (props.bgType == "sec") {
        variantStyles += " bg-gray-500";
    } else if (props.bgType == "err") {
        variantStyles += " bg-red-500"
    } else {
        variantStyles += " bg-green-500"
    }

    return (
        <button className={variantStyles}>
            <span className="fill-white">Shop Now</span>
        </button>
    );
}

export default Buttons;