import { ImHeart,ImCart } from "react-icons/im";
import { useContext, useState } from "react";
import { cartContext } from "./create-context";
function ProductCard(props) {
    let cardData = props.cardData;
    const {cart, setCart} = useContext(cartContext);
    const addToCart = () =>{
        setCart(cart+1);
    }
    //stateHook 
    const [qty, setQty]= useState(0);
    const [like, setLike]= useState(0);

    // function printQty() {
    //     console.log(qty);
    // }

    return (
        <>
            <div className="featured__item bg-gray-100 rounded ">
                <div className="featured__item__pic flex p-2" >
                    <img className="object-contain" src={cardData.image} />
                    <span className="absolute">Quantity:<b className="ml-2">{qty}</b></span>
                    <span className="absolute right-4">Like:<b className="ml-2">{like}</b></span>
                    <ul className="featured__item__pic__hover flex align-center justify-center">
                        <li><a onClick={() => {setLike(like + 1);}} className="flex align-center justify-center text-white">
                            <ImHeart className="inline" />

                        </a></li>
                        <li ><a onClick={addToCart} className="cursor-pointer flex align-center justify-center text-white">
                            <ImCart className="inline" />
                            {/* onClick={() => { setQty(qty + 1);}} */}
                        </a></li>
                    </ul>
                </div>
                <div className="featured__item__text bg-green-500 py-3 rounded-lg">
                    <h6 className=" text-white"><a href="#" ></a>{cardData.name}</h6>
                    <h5 className=" text-white">{cardData.price}</h5>
                </div>
            </div>
        </>
    );
}

export default ProductCard;