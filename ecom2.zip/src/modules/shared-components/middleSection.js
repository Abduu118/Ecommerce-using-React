import React from "react";

class MiddleSection extends React.Component {
    render(){
       return (
           <>
               <span>Middleection</span>
           </>
       )
    }
   }
   
   export default MiddleSection;